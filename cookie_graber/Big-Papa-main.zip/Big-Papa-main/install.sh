echo [*] Simple bash Script to install some python dependencies
sudo apt install python3
sudo apt install python3-pip
sudo pip3 install termcolor
echo [*] All Dependencies Successfully installed ....incase no error...!
